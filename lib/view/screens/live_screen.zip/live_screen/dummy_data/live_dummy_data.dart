List<Map<String, dynamic>> liveData = [
  {
    'imageUrl':
        'https://www.icmp.ac.uk/sites/default/files/styles/page_background/public/promote_live_music_1.jpg?itok=rJpKvxBH',
    'profile':
        'https://e7.pngegg.com/pngimages/799/987/png-clipart-computer-icons-avatar-icon-design-avatar-heroes-computer-wallpaper-thumbnail.png',
    'name': 'gaming_pro',
    'title': 'Pro Tournament Finals! Come watch!',
    'registered': '15.6K',
  },
  {
    'imageUrl':
        'https://www.icmp.ac.uk/sites/default/files/styles/page_background/public/promote_live_music_1.jpg?itok=rJpKvxBH',
    'profile':
        'https://e7.pngegg.com/pngimages/799/987/png-clipart-computer-icons-avatar-icon-design-avatar-heroes-computer-wallpaper-thumbnail.png',
    'name': 'fitness_coach',
    'title': 'HIIT Workout - Join me for 30 mins of sweat',
    'registered': '8.9K',
  },
  {
    'imageUrl':
        'https://www.icmp.ac.uk/sites/default/files/styles/page_background/public/promote_live_music_1.jpg?itok=rJpKvxBH',
    'profile':
        'https://e7.pngegg.com/pngimages/799/987/png-clipart-computer-icons-avatar-icon-design-avatar-heroes-computer-wallpaper-thumbnail.png',
    'name': 'music_live',
    'title': 'Acoustic Session - Takin\' requests!',
    'registered': '12.5K',
  },
  {
    'imageUrl':
        'https://www.icmp.ac.uk/sites/default/files/styles/page_background/public/promote_live_music_1.jpg?itok=rJpKvxBH',
    'profile':
        'https://e7.pngegg.com/pngimages/799/987/png-clipart-computer-icons-avatar-icon-design-avatar-heroes-computer-wallpaper-thumbnail.png',
    'name': 'gaming_pro',
    'title': 'Pro Tournament Finals! Come watch!',
    'registered': '15.6K',
  },
  {
    'imageUrl':
        'https://www.icmp.ac.uk/sites/default/files/styles/page_background/public/promote_live_music_1.jpg?itok=rJpKvxBH',
    'profile':
        'https://e7.pngegg.com/pngimages/799/987/png-clipart-computer-icons-avatar-icon-design-avatar-heroes-computer-wallpaper-thumbnail.png',
    'name': 'fitness_coach',
    'title': 'HIIT Workout - Join me for 30 mins of sweat',
    'registered': '8.9K',
  },
  {
    'imageUrl':
        'https://www.icmp.ac.uk/sites/default/files/styles/page_background/public/promote_live_music_1.jpg?itok=rJpKvxBH',
    'profile':
        'https://e7.pngegg.com/pngimages/799/987/png-clipart-computer-icons-avatar-icon-design-avatar-heroes-computer-wallpaper-thumbnail.png',
    'name': 'music_live',
    'title': 'Acoustic Session - Takin\' requests!',
    'registered': '12.5K',
  },
];
